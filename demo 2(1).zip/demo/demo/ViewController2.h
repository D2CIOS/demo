//
//  ViewController2.h
//  demo
//
//  Created by 翟泉 on 16/3/26.
//  Copyright © 2016年 云之彼端. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController2 : UIViewController

@end
